var ten = document.querySelector('#ten');
var thuongHieu = document.querySelector('#thuongHieu');
var gia = document.querySelector('#gia');
var noiSX = document.querySelector('#noiSX');
var link = document.querySelector('#link');
var submit = document.querySelector('#submit');

var errorTen = document.querySelector('#errorTen');
var errorThuongHieu = document.querySelector('#errorThuongHieu');
var errorGia = document.querySelector('#errorGia');
var errorNoiSX = document.querySelector('#errorNoiSX');
var errorLink = document.querySelector('#errorLink');

var tbody = document.querySelector('tbody');
var sanPham=[];

submit.onclick=function(x){
    x.preventDefault();
    var check= true;
    if(ten.value.trim() == ''){
        errorTen.innerHTML='Không được để trống tên sản phẩm';
        check=false;
    } else if(ten.value.trim().length <10){
        errorTen.innerHTML='Tên sản phẩm tối thi';
        check=false;
    }
    else{
        errorTen.innerHTML=''
    }

    if(thuongHieu.value.trim() == ''){
        errorThuongHieu.innerHTML='Không được để trống thương hiệu';
        check=false;
    }
    else{
        errorThuongHieu.innerHTML=''
    }

    if(gia.value.trim() == ''){
        errorGia.innerHTML='Không được để trống giá sản phẩm';
        check=false;
    }
    else{
        errorGia.innerHTML=''
    }

    if(noiSX.value.trim() == ''){
        errorNoiSX.innerHTML='Không được để trống nơi sản xuất';
        check=false;
    }
    else{
        errorNoiSX.innerHTML=''
    }

    if(link.value.trim() == ''){
        errorLink.innerHTML='Không được để trống link hình ảnh';
        check=false;
    }
    else{
        errorLink.innerHTML=''
    }
    var obj={

    }
    if(check== true){
        sanPham.push(obj)
    }
    
}
