do{
    var chon=prompt('Mời chọn chương trình: ');
    switch(chon){
        case '1':
            var username=['ha','yen','long','duc','dang','duong','bang'];
            console.log('Mảng username: ');
            for(i=0 ;i<username.length ;i++){
                console.log(username[i]);
            }
            username.push('sontv8');
            console.log('Mảng sau khi thêm phần tử: ');
            for(i=0 ;i<username.length ;i++){
                console.log(username[i]);
            }
            username.shift();
            console.log('Mảng sau khi xóa phần tử đầu tiên: ');
            for(i=0 ;i<username.length ;i++){
                console.log(username[i]);
            }
            username.pop();
            console.log('Mảng sau khi xóa phần tử cuối cùng: ');
            for(i=0 ;i<username.length ;i++){
                console.log(username[i]);
            }
            username.splice(3,1);
            console.log('Mảng sau khi xóa phần tử thứ 4: ');
            for(i=0 ;i<username.length ;i++){
                console.log(username[i]);
            }
            console.log('***************');
            break;
        case '2':
            var users = ['sontv8','datlt34','thienth','tiennh21','minhdq8'];
            var ten = prompt("Nhập tên cần tìm");
            if(users.includes(ten)==true){
                console.log('Tài khoản đăng nhập: '+ten);
            }
            else{console.log('Tài khoản bạn vừa nhập không tồn tại');}
            users.push('dungna');
            console.log('Mảng sau khi thêm phần tử: ');
            for(i=0 ;i<users.length ;i++){
                console.log(users[i]);
            }
            console.log('***************');
            break;
        case '3':
            var numbers = [];
            for(i=0; i<5; i++){
                numbers[i] = prompt('Nhập phần tử thứ '+i+' : ');
            }
            console.log('Mảng numbers: ');
            for(i=0; i<5; i++){
                console.log(numbers[i]);
            }
            console.log('***************');
            break;
        case '4':
            var so = [4,12,7,45,26];
            var count=0;
            for(var index of so){
                if(index %2 !=0){
                    count++;
                }
            }
            if(count == 0){
                console.log('Yes');
            }
            else{console.log('No')}
            console.log('***************');
            break;
        case '5':
            var soNguyen = [1,4,5,7,22,15,9,8];
            var evenData =[];
            for(var index of soNguyen){
                if(index %2 == 0){
                    evenData.push(index);
                }
            }
            console.log('Mảng evenData: ')
            for(i=0; i<evenData.length; i++){
                console.log(evenData[i]);
            }
            console.log('***************');
            break;
        case '6':
            var users=['sontv', 'datlt', 'thienth'];
            console.log('Mảng users: ');
            for(i=0; i<users.length; i++){
                console.log(users[i]);
            }
            users.push('huynh');
            users.splice(0,1,'tiennh');
            users.splice(2,1);
            console.log('Mảng users: ');
            for(i=0; i<users.length; i++){
                console.log(users[i]);
            }
            console.log('***************');
            break;
        case '7':
            var carBrand = ['audi', 'volvo', 'lamborghini', 'ferrari', 'porsche']
            var carColor = ['red', 'black', 'white', 'orange'];
            var carSelected = [];
            var tenXe = prompt('Nhập tên xe: ');
            var mauXe = prompt('Nhập màu xe: ');
            if(carBrand.includes(tenXe) == true && carColor.includes(mauXe) ==true){
                carSelected.push(tenXe,mauXe);
                console.log('Mảng carSelected: ')
                for(i=0; i<carSelected.length; i++){
                    console.log( carSelected[i] );
                }
            }
            else{ console.log('Không có xe')}
            console.log('***************');
            break;
        case '8':
            var users = [];
            themMang();
            hienMang();
            timVaSua();
            hienMang();
            timVaXoa();
            hienMang();
            
            break;
        case '9':
            var products =['mercedes', 'audi', 'ford', 'lamborghini'];
            showProduct();
            addProduct();
            removeProduct();
            updateProduct();
            removeAllProduct();
            break;

    }
}while(chon>=0 && chon<=9);

function themMang(){
    var user = prompt('Nhập user muốn thêm: ');
    users.push(user);
}
function timVaSua(){
    var user = prompt('Nhập tên muốn tìm và sửa: ');
    for(i=0; i<users.length; i++){
        if(users[i] == user){
            var ten = prompt('Nhập tên mới: ');
            users.splice(i,1,ten);
        }
    }
}
function timVaXoa(){
    var user = prompt('Nhập tên muốn tìm và xóa: ');
    for(i=0; i<users.length; i++){
        if(users[i] == user){
            users.splice(i,1);
        }
    }
}
function hienMang(){
    for(i=0; i<users.length; i++){
        console.log(users[i]);
    }
}

function showProduct(){
    if(products.length == 0){
        console.log('Không có sản phẩm để hiển thị');
    }
    else{
        for(i=0; i<products.length; i++){
            console.log(products[i]);
        }
    }
    
}
function addProduct() {
    var tenSP = prompt('Nhập tên sản phẩm muốn thêm: ');
    if(tenSP.length <5 ){
        tenSP = prompt('Nhập lại tên sản phẩm >5 ký tự: ');
    }
    else{
        products.push(tenSP);
        console.log('Mảng products sau khi thêm: ');
        showProduct();
    }
}
function removeProduct(){
    var ten = prompt('Nhập tên sản phẩm cần xóa: ');
    var dem =0;
    var a;
    for(i=0; i<products.length; i++){
        if(products[i] == ten){
            dem++;
            a=i;
        }
    }
    if(dem != 0){
        products.splice(a,1);
        console.log('Mảng products sau khi xóa: ');
        showProduct();
    }
    else if(dem == 0){
        console.log('Không tìm thấy sản phẩm cần xóa');
    }
}
function updateProduct(){
    var ten = prompt('Nhập tên sản phẩm cần cập nhật: ');
    var dem = 0;
    var a;
    for(i=0; i<products.length; i++){
        if(products[i] == ten){
            dem++;
            a=i;
        }
    }
    if(dem != 0){
        var tenMoi = prompt('Nhập tên mới: ');
        products.splice(a,1,tenMoi);
        console.log('Mảng products sau khi cập nhật: ');
        showProduct();
    }
    else if(dem == 0){
        console.log('Không tìm thấy sản phẩm cần cập nhật');
    }
}
function removeAllProduct(){
    products.splice(0,products.length);
    showProduct();
}