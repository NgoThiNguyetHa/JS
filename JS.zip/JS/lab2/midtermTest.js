var products =['mercedes', 'audi', 'ford', 'lamborghini'];
showProduct();
addProduct();
removeProduct();
updateProduct();
removeAllProduct();
function showProduct(){
    if(products.length == 0){
        console.log('Không có sản phẩm để hiển thị');
    }
    else{
        for(i=0; i<products.length; i++){
            console.log(products[i]);
        }
    }
    
}
function addProduct() {
    var tenSP = prompt('Nhập tên sản phẩm muốn thêm: ');
    if(tenSP.length <5 ){
        tenSP = prompt('Nhập lại tên sản phẩm >5 ký tự: ');
        products.push(tenSP);
        console.log('Mảng products sau khi thêm: ');
        showProduct();
    }
    else{
        products.push(tenSP);
        console.log('Mảng products sau khi thêm: ');
        showProduct();
    }
}
function removeProduct(){
    var ten = prompt('Nhập tên sản phẩm cần xóa: ');
    var dem =0;
    var a;
    for(i=0; i<products.length; i++){
        if(products[i] == ten){
            dem++;
            a=i;
        }
    }
    if(dem != 0){
        products.splice(a,1);
        console.log('Mảng products sau khi xóa: ');
        showProduct();
    }
    else if(dem == 0){
        console.log('Không tìm thấy sản phẩm cần xóa');
    }
}
function updateProduct(){
    var ten = prompt('Nhập tên sản phẩm cần cập nhật: ');
    var dem = 0;
    var a;
    for(i=0; i<products.length; i++){
        if(products[i] == ten){
            dem++;
            a=i;
        }
    }
    if(dem != 0){
        var tenMoi = prompt('Nhập tên mới: ');
        products.splice(a,1,tenMoi);
        console.log('Mảng products sau khi cập nhật: ');
        showProduct();
    }
    else if(dem == 0){
        console.log('Không tìm thấy sản phẩm cần cập nhật');
    }
}
function removeAllProduct(){
    products.splice(0,products.length);
    showProduct();
}