
do{
    console.log("1. Xếp loại học lực cho học sinh");
    console.log("2. Phân loại chuối theo độ dài");
    console.log("3. Tính lãi ngân hàng");
    console.log("4. Đếm các số chia hết cho 2");
    console.log("5. Kiểm tra số");
    console.log("6. Kiểm tra điểm của sinh viên");
    console.log("7. Tính số lượng bò");
    console.log("8. Tính lương");
    console.log("9. Nhập điểm lab, quiz, assignment, điểm thi");
    console.log("10. Tính tổng các số chia hết cho 3 và 5");
    
    var chon= prompt("Mời chọn chương trình: ");
    switch(chon){
        case '1': 
            var diem = prompt("Mời nhập điểm: ");
            if(diem>=0 && diem<5){
                console.log("Học lực yếu");
            }
            else if(diem>=5 && diem<6.5){
                console.log("Học lực trung bình");
            }
            else if(diem>=6.5 && diem<8){
                console.log("Học lực khá");
            }
            else if(diem>=8 && diem<10){
                console.log("Học lực giỏi");
            }
            else{
                console.log("Nhập điểm lỗi rồi");
            }
            break;
        case '2':
            var chuoi = prompt("Nhập độ dài của chuối: ");
            if(chuoi>=10 && chuoi<15){
                console.log("Chuối tạm được");
            }
            else if(chuoi>0 && chuoi<10){
                console.log("Chuối quá nhỏ, không mua");
            }
            else if(diem<0){
                console.log("Nhập sai rồi");
            }

            else{
                console.log("Chuối khủng, mua ngay");
            }
            break;
        case '3':
            var tiengoc = 10000;
            var tienlai=0;
            for(i=1; i<=12; i++){
                tienlai +=((tiengoc*10)/100)*i;
                console.log("Tiền lãi sau tháng "+i+" là: "+tienlai);

            }
            var tongTien = tiengoc+tienlai;
            console.log("Tổng tiền sau 12 tháng là: "+tongTien);
            break;
        case '4':
            var n = prompt("Nhập một số bất kì: ");
            var dem=0;
            for(i=1; i<=n; i++){
                if(i%2==0){
                    console.log(i);
                    dem++;
                }
            }
            console.log("Có "+dem+" số chia hết cho 2"); 
        case '5':
            var x1 = prompt("Nhập một giá trị cần kiểm tra: ");
            if(isNaN(x1) == false){
                console.log("Đây là số");
            }
            else{
                console.log("Đây không phải là số");
            }
            break;
        case '6':
            
            var hoTen= prompt("Nhập họ tên sinh viên: ");
            var diem = prompt("Nhập điểm của sinh viên: ");
            console.log("Họ tên: "+hoTen); 
            switch(diem){
                case 'A': case'B': case 'C':
                    console.log("Đủ điều kiện qua môn");
                    break;
                case 'D': case 'F':
                    console.log("Không đủ điều kiện qua môn");
                    break;
                default: console.log("Điểm không xác định"); 
            }
            break;
        case '7':
            var soBoBanDau=1000;
            var soBoMuaThem=0;
            console.log("Số bò ban đầu là: "+soBoBanDau);
            for(i=1; i<=9; i++){
                soBoMuaThem +=15;
            }
            console.log("Số lượng bò mua thêm được là: "+soBoMuaThem);
            console.log("Số lượng bò sau khi mua thêm là: "+(soBoMuaThem+soBoBanDau));
            break;
        case '8':
            var HoTen = prompt("Nhập họ tên nhân viên: ");
            var tuoi = prompt("Nhập tuổi nhân viên: ");
            var mucLuong = prompt("Nhập mức lương: ");
            var soThang = prompt("Nhập số tháng đi làm trong năm: ");
            var thuong;
            console.log("Tổng lương của cả năm là: "+(mucLuong*soThang));
            if(soThang<3){
                thuong=2000000;
                console.log("Số tiền thưởng là: "+thuong);
            }
            else if(soThang>=3 && soThang<6){
                thuong=60000000;
                console.log("Số tiền thưởng là: "+thuong);
            }
            else{
                thuong=12000000;
                console.log("Số tiền thưởng là: "+thuong);
            }
            console.log("Tổng thu nhập bao gồm cả lương và thưởng là: "+((mucLuong*soThang)+thuong));
            break;
        case '9':
            var diemLab = prompt("Nhập điểm lab: ");
            var diemQuiz = prompt("Nhập điểm quiz: ");
            var diemAsm = prompt("Nhập điểm assignment: ");
            var diemThi = prompt("Nhập điểm thi: ");
            if(diemAsm<0 || diemAsm>10 || diemLab<0 || diemLab>10 || diemQuiz<0 || diemQuiz>10 || diemThi<0 || diemThi>10){
                console.log("Lỗi nhập điểm");
            }
            else{
                console.log("Điểm lab: "+diemLab);
                console.log("Điểm quiz: "+diemQuiz); 
                console.log("Điểm assignment: "+diemAsm);
                console.log("Điểm thi: "+diemThi);
                var diemTB = (diemLab*30/100)+(diemQuiz*10/100)+(diemAsm*20/100)+(diemThi*40/100);
                console.log("Điểm trung bình: "+diemTB);
                if(diemTB<5){
                    console.log("Bạn đã trượt môn");
                }
                else{
                    console.log("Bạn đã qua môn");
                }
            }
            break;
        case '10':
            var x = prompt("Nhập 1 số dương bất kì: ");
            var tong = 0;

            if(x>=0){
                for(i=0; i<=x; i++){
                    if(i%5==0 && i%3==0){
                        tong+=i;
                    }
                }
                console.log("Tổng các số chia hết cho 3 và 5 là: "+tong)
            }
            else{
                console.log("Bạn phải nhập số dương");
            }
    }
}while(chon>0 && chon<=10);