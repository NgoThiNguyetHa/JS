var ten = document.querySelector("#tenSP");
var ma = document.querySelector("#maSP");
var nhaCC = document.querySelector("#nhaCungCap");
var soLuong = document.querySelector("#soLuong");
var gia = document.querySelector("#giaTien");
var tinhTrang = document.querySelector("#tinhTrang");
var submit = document.querySelector("#submit");
var error = document.querySelector("#error");
var table = document.querySelector("#table");
    

var hoaDon = [];
var object={};

submit.onclick = function(x){
    x.preventDefault();
    if(ten.value==""){
        error.innerHTML='Tên sản phẩm không được để trống';
        return false;
    } else if(ten.value.length<5){
        error.innerHTML='Tên sản phẩm tối thiểu 5 kí tự';
        return false;
    }
    if(ma.value==""){
        error.innerHTML='Mã sản phẩm không được để trống';
        return false;
    }
    if(nhaCC.value==""){
        error.innerHTML='Nhà cung cấp không được để trống';
        return false;
    }
    if(soLuong.value==""){
        error.innerHTML='Số lượng không được để trống';
        return false;
    }
    if(gia.value==""){
        error.innerHTML='Giá tiền không được để trống';
        return false;
    } else if(gia.value<0){
        error.innerHTML='Giá tiền phải lớn hơn 0';
        return false;
    }
    if(tinhTrang.value==""){
        error.innerHTML='Tình trạng không được để trống';
        return false;
    }

    error.innerHTML="Nhập kho thành công";
    object.tenSP = tenSP.value;
    object.maSP = ma.value;
    object.nhaCC = nhaCC.value;
    object.soLuong = soLuong.value;
    object.gia = gia.value;
    

    hoaDon.push(object);
    for(var i of hoaDon){
        table.innerHTML=`
            <tr>
                <th>Tên sản phẩm</th>
                <th>Mã sản phẩm</th>
                <th>Nhà cung cấp</th>
                <th>Số lượng</th>
                <th>Giá tiền</th>
                <th>Status</th>
            </tr>
            <tr>
                <td>${object.tenSP}</td>
                <td>${object.maSP}</td>
                <td>${object.nhaCC}</td>
                <td>${object.soLuong}</td>
                <td>${object.gia}</td>
                <td>Còn hàng</td>
            </tr>`
    }
    return true;
}