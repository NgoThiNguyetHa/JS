var tenSP = document.querySelector('#ten');
var thuongHieu = document.querySelector('#thuongHieu');
var gia = document.querySelector('#gia');
var noiSX = document.querySelector('#noiSX');
var link = document.querySelector('#link');
var submit = document.querySelector('#submit');
var table = document.querySelector('table');

var errorTen = document.querySelector('#errorTen');
var errorThuongHieu = document.querySelector('#errorThuongHieu');
var errorGia = document.querySelector('#errorGia');
var errorNoiSX = document.querySelector('#errorNoiSX');
var errorLink = document.querySelector('#errorLink');
var error = document.querySelector('#error');

var array=[];

submit.onclick= function(x){
    x.preventDefault();
    if(tenSP.value == ''){
        errorTen.innerHTML='Không được để trống tên sản phẩm';
        return false;
    }
    if(tenSP.value.length <10){
        errorTen.innerHTML='Tên sản phẩm tối thiểu 10 ký tự';
        return false;
    }
    if(thuongHieu.value == ''){
        errorThuongHieu.innerHTML='Không được để trống thương hiệu';
        return false;
    }
    if(gia.value == ''){
        errorGia.innerHTML='Không được để trống giá sản phẩm';
        return false;
    }
    if(gia.value <0){
        errorGia.innerHTML='Giá sản phẩm phải là số dương';
        return false;
    }
    if(noiSX.value == ''){
        errorNoiSX.innerHTML='Không được để trống nơi sản xuất';
        return false;
    }
    if(link.value == ''){
        errorLink.innerHTML='Không được để trống link hình ảnh';
        return false;
    }
    var obj = {
        ten: tenSP.value,
        thuongHieu: thuongHieu.value,
        gia: gia.value,
        noiSX: noiSX.value,
        anh: link.value
    }
    array.push(obj);
    show();
}
function show(){
    table.innerHTML='';
    for(var i = 0; i<array.length; i++){
        table.innerHTML+=`
        <tr>
                <th>Tên sản phẩm:</th>
                <td>${array[i].ten}</td>
            </tr>
            <tr>
                <th>Thương hiệu:</th>
                <td>${array[i].thuongHieu}</td>
            </tr>
            <tr>
                <th>Giá sản phẩm:</th>
                <td>${array[i].gia}</td>
            </tr>
            <tr>
                <th>Nơi sản xuất:</th>
                <td>${array[i].noiSX}</td>
            </tr>
            <tr>
                <th><img src="${array[i].anh}" alt=""></th>
                <td><button id="xoa" onclick='deletes(${i})'>Xóa</button></td>
            </tr>
        `
    }
}
function deletes(i){
    if(confirm('Bạn có muốn xóa?') == true){
        array.splice(i,1);
        show();
    }
}