var user = document.querySelector('#user');
var password = document.querySelector('#password');
var repassword = document.querySelector('#repassword');
var email = document.querySelector('#email');
var tinhTrang = document.querySelector('#tinhTrang');
var errorUser = document.querySelector('#errorUser');
var errorPass = document.querySelector('#errorPass');
var errorRepass = document.querySelector('#errorRepass');
var errorEmail = document.querySelector('#errorEmail');
var errorTinhTrang = document.querySelector('#errorTinhTrang');
var submit = document.querySelector('#submit');
var tbody = document.querySelector('tbody');
var error = document.querySelector('#error');

var array = [];

submit.onclick = function(x){
    x.preventDefault();
    if(user.value == ""){
        errorUser.innerHTML='Không được để trống username';
        return false;
    }
    if(password.value == ""){
        errorPass.innerHTML='Không được để trống password';
        return false;
    } 
    if(password.value.length<8){
        errorPass.innerHTML='Password tối thiểu 8 kí tự';
        return false;
    } 
    if(repassword.value == ""){
        errorRepass.innerHTML='Không được để trống repassword';
        return false;
    }
    if(password.value!=repassword.value){
        errorRepass.innerHTML='Repassword không giống password';
        return false;
    }
    if(email.value == ""){
        errorEmail.innerHTML='Không được để trống email';
        return false;
    }
    if(tinhTrang.value == ""){
        errorTinhTrang.innerHTML='Không được để trống tình trạng';
        return false;
    }
    error.innerHTML='Đăng ký thành công';
    var obj ={
        username: user.value,
        password: password.value,
        email: email.value,
        tinhTrang: tinhTrang.value
    }
    array.push(obj);
    show();
    }
    

function show(){
    tbody.innerHTML='';
    for(var i=0; i<array.length; i++){
        tbody.innerHTML+=`
        <tr>
        <td>${array[i].username}</td>
        <td>${array[i].password}</td>
        <td>${array[i].email}</td>
        <td>${array[i].tinhTrang}</td>
        <td><button id="xoa" onclick="deletes(${i})">Xóa</button></td>
    </tr>`
}
}
function deletes(i){
    if(confirm("Bạn có muốn xóa user này?") ==true){
        array.splice(i,1);
        show();
    }
}