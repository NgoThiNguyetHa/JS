var black = document.querySelector(".khoiDen");
black.style.background = 'orange';
black.style.width = '300px';
black.style.height = '200px';
black.style.border = '1px solid blue';

document.querySelector('.container').style.width = '400px';

document.querySelector('button').style.width = '100%';
document.querySelector('button').style.height = '30px';
document.querySelector('button').style.color = 'white';
document.querySelector('button').style.backgroundColor = 'rgb(54, 151, 241)';
document.querySelector('button').style.border = 'none';
document.querySelector('button').style.fontWeight = 'bold';
document.querySelector('button').style.borderRadius = '5px';

document.querySelector('.text1').style.border = '1px solid rgb(54, 151, 241)';
document.querySelector('.text1').style.borderRadius = '5px';
document.querySelector('.text1').style.width = '98%';
document.querySelector('.text1').style.height = '30px';

document.querySelector('.text2').style.border = '1px solid rgb(54, 151, 241)';
document.querySelector('.text2').style.borderRadius = '5px';
document.querySelector('.text2').style.width = '98%';
document.querySelector('.text2').style.height = '30px';

document.querySelector('a').style.color = 'rgb(54, 151, 241)';
document.querySelector('a').style.float = 'right';
