var user = document.querySelector('#user');
var password = document.querySelector('#password');
var repassword = document.querySelector('#repassword');
var email = document.querySelector('#email');
var tinhTrang = document.querySelector('#tinhTrang');
var submit = document.querySelector('#submit');

var errorUser = document.querySelector('#errorUser');
var errorPass = document.querySelector('#errorPass');
var errorRepass = document.querySelector('#errorRepass');
var errorEmail = document.querySelector('#errorEmail');
var errorTinhTrang = document.querySelector('#errorTinhTrang');
var error = document.querySelector('#error');

var tbody = document.querySelector('tbody');
var users =[];

submit.onclick= function(x){
    x.preventDefault();
    if(user.value.trim() ==''){
        errorUser.innerHTML='Không được để trống username';
    }
    else{
        errorUser.innerHTML='';
    }
    if(password.value.trim() ==''){
        errorPass.innerHTML='Không được để trống password';
    }
    else if(password.value.trim().length <8){
        errorPass.innerHTML='Password tối thiểu 8 ký tự';
    }
    else{
        errorPass.innerHTML='';
    }
    if(repassword.value.trim() ==''){
        errorRepass.innerHTML='Không được để trống re-password';
    }
    else if(repassword.value.trim() != password.value.trim()){
        errorRepass.innerHTML='Re-password phải trùng với password';
    }
    else{
        errorRepass.innerHTML='';
    }
    if(email.value.trim() ==''){
        errorEmail.innerHTML='Không được để trống email';
    }
    else{
        errorEmail.innerHTML='';
    }
    if(tinhTrang.value.trim() ==''){
        errorTinhTrang.innerHTML='Không được để trống tình trạng';
        return false;
    }
    errorTinhTrang.innerHTML='';
    error.innerHTML='Thêm mới username thành công'

    var obj={
        user : user.value,
        password: password.value,
        email: email.value,
        tinhTrang: tinhTrang.value
    }
    users.push(obj);
    themUser();
}
function themUser(){
    tbody.innerHTML='';
    for(var i=0; i<users.length; i++){
        tbody.innerHTML+=`
        <tr>
                <td>${users[i].user}</td>
                <td>${users[i].password}</td>
                <td>${users[i].email}</td>
                <td>${users[i].tinhTrang}</td>
                <td> <button id="xoa" onclick='xoa(${i})'>Xóa</button></td>
        </tr>
        `
    }
}
function xoa(i){
    if(confirm("Bạn có muốn xóa user này?") == true){
        users.splice(i,1);
        themUser();
    }
}