var ten = document.querySelector('#ten');
var thuongHieu = document.querySelector('#thuongHieu');
var gia = document.querySelector('#gia');
var noiSX = document.querySelector('#noiSX');
var link = document.querySelector('#link');
var submit = document.querySelector('#submit');

var errorTen = document.querySelector('#errorTen');
var errorThuongHieu = document.querySelector('#errorThuongHieu');
var errorGia = document.querySelector('#errorGia');
var errorNoiSX = document.querySelector('#errorNoiSX');
var errorLink = document.querySelector('#errorLink');
var error = document.querySelector('#error');

var table = document.querySelector('table');

var sanPham = [];

submit.onclick = function(x){
    x.preventDefault();
    if(ten.value.trim() == ""){
        errorTen.innerHTML='Không được để trống tên sản phẩm'
        return false;
    }
    if(ten.value.trim().length <10){
        errorTen.innerHTML='Tên sản phẩm tối thiểu 10 ký tự'
        return false;
    }
    if(thuongHieu.value.trim() == ""){
        errorThuongHieu.innerHTML='Không được để trống thương hiệu'
        return false;
    }
    if(gia.value.trim() == ""){
        errorGia.innerHTML='Không được để trống giá sản phẩm'
        return false;
    }
    if(isNaN(gia.value) == true){
        errorGia.innerHTML='Giá sản phẩm phải là số dương'
        return false;
    }
    if(gia.value <0){
        errorGia.innerHTML='Giá sản phẩm phải là số dương'
        return false;
    }
    if(noiSX.value.trim() == ""){
        errorNoiSX.innerHTML='Không được để trống nơi sản xuất'
        return false;
    }
    if(link.value.trim() == ""){
        errorLink.innerHTML='Không được để trống link hình ảnh'
        return false;
    }
    error.innerHTML='Thêm sản phẩm thành công';
    var obj={
        tenSP: ten.value,
        thuongHieu: thuongHieu.value,
        giaSP: gia.value,
        noiSX: noiSX.value,
        link: link.value
    }
    sanPham.push(obj);
    themSP();
}
function themSP(){
    table.innerHTML='';
    for(var i=0; i<sanPham.length; i++){
        table.innerHTML+=`
        <tr>
        <th>Tên sản phẩm</th>
        <td>${sanPham[i].tenSP}</td>
    </tr>
    <tr>
        <th>Thương hiệu</th>
        <td>${sanPham[i].thuongHieu}</td>
    </tr>
    <tr>
        <th>Giá sản phẩm</th>
        <td>${sanPham[i].giaSP}</td>
    </tr>
    <tr>
        <th>Nơi sản xuất</th>
        <td>${sanPham[i].noiSX}</td>
    </tr>
    <tr>
        <th><img src="${sanPham[i].link}" alt=""></th>
        <td><button id="xoa" onclick='xoa(${i})'>Xóa</button></td>
    </tr>
        `
    }
    
}
function xoa(i){
    if(confirm("Bạn có muốn xóa sản phẩm này không?") == true){
        sanPham.splice(i,1);
        themSP();
    }
}
