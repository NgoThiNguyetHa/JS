var ten = document.querySelector('#ten');
var thuongHieu = document.querySelector('#thuongHieu');
var gia = document.querySelector('#gia');
var noiSX = document.querySelector('#noiSX');
var link = document.querySelector('#link');
var submit = document.querySelector('#submit');

var errorTen = document.querySelector('#errorTen');
var errorThuongHieu = document.querySelector('#errorThuongHieu');
var errorGia = document.querySelector('#errorGia');
var errorNoiSX = document.querySelector('#errorNoiSX');
var errorLink = document.querySelector('#errorLink');

var table = document.querySelector('table');
var sanPham=[];

submit.onclick = function(x){

    x.preventDefault();
    var check = true;
    if(ten.value.trim() ==''){
        errorTen.innerHTML='Không được để trống tên sản phẩm'
        check=false;
    }else if(ten.value.trim().length <10){
        errorTen.innerHTML='Tên sản phẩm tối thiểu 10 ký tự'
        check=false;
    }
    else{
        errorTen.innerHTML='';
    }
    //
    if(thuongHieu.value.trim() ==''){
        errorThuongHieu.innerHTML='Không được để trống thương hiệu'
        check=false;
    }else{
        errorThuongHieu.innerHTML='';
    }
    //
    if(gia.value.trim() ==''){
        errorGia.innerHTML='Không được để trống giá sản phẩm'
        check=false;
    }else if(isNaN(gia.value) || gia.value.trim() <0){
        errorGia.innerHTML='Giá sản phẩm phải là số dương'
        check=false;
    }
    else{
        errorGia.innerHTML='';
    }
    //
    if(noiSX.value.trim() ==''){
        errorNoiSX.innerHTML='Không được để trống nơi sản xuất'
        check=false;
    }else{
        errorNoiSX.innerHTML='';
    }
    //
    if(link.value.trim() ==''){
        errorLink.innerHTML='Không được để trống link hình ảnh'
        check=false;
        
    }else{
        errorLink.innerHTML='';
    }
    
    var obj = {
        ten: ten.value,
        thuongHieu: thuongHieu.value,
        gia: gia.value,
        noiSX: noiSX.value,
        link: link.value
    }
    if(check){
        sanPham.push(obj);
    }
    
    themSP();
}
function themSP(){
    table.innerHTML='';
    for(var i=0; i<sanPham.length; i++){
        table.innerHTML=`
        <tr>
            <th>Tên sản phẩm:</th>
            <td>${sanPham[i].ten}</td>
        </tr>
        <tr>
            <th>Mã sản phẩm:</th>
            <td>${sanPham[i].thuongHieu}</td>
        </tr>
        <tr>
            <th>Giá sản phẩm:</th>
            <td>${sanPham[i].gia}</td>
        </tr>
        <tr>
            <th>Nơi sản xuất:</th>
            <td>${sanPham[i].noiSX}</td>
        </tr>
        <tr>
            <th><img src="${sanPham[i].link}" alt=""></th>
            <td><button id='xoa' onclick='xoa(${i})'>Xóa</button></td>
        </tr>
        `
    }
}
function xoa(i){
    if(confirm("Bạn có muốn xóa sp này?") == true){
        sanPham.splice(i,1);
        themSP();
    }
}