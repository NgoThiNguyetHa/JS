var ten = document.querySelector('#ten');
var maSP = document.querySelector('#maSP');
var nhaCC = document.querySelector('#nhaCC');
var soLuong = document.querySelector('#soLuong');
var gia = document.querySelector('#gia');
var tinhTrang = document.querySelector('#tinhTrang');
var submit = document.querySelector('#submit');

var errorTen = document.querySelector('#errorTen');
var errorMaSP = document.querySelector('#errorMaSP');
var errorNhaCC = document.querySelector('#errorNhaCC');
var errorSL = document.querySelector('#errorSL');
var errorGia = document.querySelector('#errorGia');
var errorTinhTrang = document.querySelector('#errorTinhTrang');
var error = document.querySelector('#error');

var tbody = document.querySelector('tbody');
var sanPham = [];

submit.onclick = function(x){
    x.preventDefault();
    if(ten.value.trim() == ''){
        errorTen.innerHTML= 'Không được để trống tên sản phẩm'
    } else if(ten.value.length <5){
        errorTen.innerHTML='Tên sản phẩm tối thiểu 5 ký tự'
    }
    else{
        errorTen.innerHTML='';
    }
    //
    if(maSP.value.trim() == ''){
        errorMaSP.innerHTML= 'Không được để trống mã sản phẩm'
    }else{
        errorMaSP.innerHTML='';
    }
    //
    if(nhaCC.value.trim() == ''){
        errorNhaCC.innerHTML= 'Không được để trống nhà cung cấp'
    }else{
        errorNhaCC.innerHTML='';
    }
    //
    if(soLuong.value.trim() == ''){
        errorSL.innerHTML= 'Không được để trống số lượng'
    }else if(isNaN(soLuong.value)== true || soLuong.value<0){
        errorSL.innerHTML='Số lượng phải là là số dương'
    }
    else{
        errorSL.innerHTML='';
    }
    //
    if(gia.value.trim() == ''){
        errorGia.innerHTML= 'Không được để trống giá tiền'
    }else if(isNaN(gia.value)== true || gia.value<0){
        errorGia.innerHTML='Giá tiền phải là là số dương'
    }
    else{
        errorGia.innerHTML='';
    }
    //
    if(tinhTrang.value.trim() == ''){
        errorTinhTrang.innerHTML= 'Không được để trống giá tiền'
        return false;
    }else{
        errorTinhTrang.innerHTML='';
        
    }
    error.innerHTML='Thêm sản phẩm thành công'
    var obj = {
        ten: ten.value,
        maSP: maSP.value,
        nhaCC: nhaCC.value,
        soLuong: soLuong.value,
        gia: gia.value,
        tinhTrang: tinhTrang.value
    }
    sanPham.push(obj);
    themSP();
}
function themSP(){
    tbody.innerHTML='';
    for(var i of sanPham){
        tbody.innerHTML+=`
            <tr>
                <td>${i.ten}</td>
                <td>${i.maSP}</td>
                <td>${i.nhaCC}</td>
                <td>${i.soLuong}</td>
                <td>${i.gia}</td>
                <td>Còn hàng</td>
            </tr>
        `
    }
}