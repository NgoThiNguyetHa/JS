var soLuong = document.querySelector("#soLuong");
var sanPham = document.querySelector("#sanPham");
var loai = document.querySelector("#loai");
var donGia = document.querySelector("#donGia");
var noiThanh = document.querySelector("#noiThanh");
var ngoaiThanh = document.querySelector("#ngoaiThanh");
var datMua = document.querySelector("#datMua");
var error = document.querySelector(".error");
var thongTin = document.querySelector("#thongTin");
var noiNhanHang, phi;

ngoaiThanh.onclick = function(){
    if(ngoaiThanh.checked){
        
        var box = document.getElementById('phiVanChuyen');
        box.style.display = "block";
    }
}
noiThanh.onclick = function(){
    if(noiThanh.checked){
        
        var box = document.getElementById('phiVanChuyen');
        box.style.display = "none";
    }
}
datMua.addEventListener("click", function(x){
    x.preventDefault();
    if(sanPham.value == ""){
        error.innerHTML = "Sản phẩm không được để trống";
        return false;
    }
    if(donGia.value == ""){
        error.innerHTML = "Đơn giá không được để trống";
        return false;
    }else if(donGia.value <0){
        error.innerHTML = "Đơn giá phải lớn hơn 0";
        return false;
    }
    if(loai.value == ""){
        error.innerHTML = "Loại không được để trống";
        return false;
    }
    if(!noiThanh.checked && !ngoaiThanh.checked){
        error.innerHTML = "Nơi nhận hàng không được để trống";
        return false;
    } 
    if(isNaN(soLuong.value) == true){
        error.innerHTML = "Số lượng phải là số";
        return false;
    } else if(soLuong.value == ""){
        error.innerHTML = "Số lượng không được để trống";
        return false;
    }
    error.innerHTML ="Đặt mua thành công";
    if(noiThanh.checked){
        noiNhanHang = "Nội thành";
        phi = 0;
    }else if(ngoaiThanh.checked){
        noiNhanHang= "Ngoại thành";
        phi = 100000;
    }
    
    thongTin.innerHTML = "Sản phẩm: "+sanPham.value+ "Loại: "+loai.value+"Đơn giá: "+ donGia.value+
                         "Nơi nhận hàng: "+noiNhanHang+"Phí vận chuyển: "+ phi+
                         "Tổng tiền: "+(donGia.value*soLuong.value+phi);
    
    return true;
})

