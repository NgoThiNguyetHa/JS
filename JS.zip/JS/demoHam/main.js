function tinhTong(x,y){
    
    return x+y;
}