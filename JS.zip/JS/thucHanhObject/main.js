var product = [
    {
        id: 1,
        name: "iPhone ",
        image: "https://image.cellphones.com.vn/358x/media/catalog/product/i/p/iphone_13-_pro-5_4.jpg "
    },
    {
        id: 2,
        name: "xiaoMi ",
        image: "https://image.cellphones.com.vn/358x/media/catalog/product/x/i/xiaomi-12-pro_arenamobiles.jpg "
    },
    {
        id: 3,
        name: "samsung ",
        image: "https://image.cellphones.com.vn/358x/media/catalog/product/g/a/galaxy-z-fold3-kv_5g__1p_cmyk_1.jpg "
    }
]
var productDiv = document.querySelector(".product");
for(var i of product){
    productDiv.innerHTML += `
    <tr>
    <td>${i.id}</td>
    <td>${i.name}</td>
    <td><img src="${i.image}" alt=""></td>
    </tr>`
}