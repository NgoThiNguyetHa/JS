/*
Khai báo mảng: 
[từ khóa] [tên mảng] = new Array();
[từ khóa] [tên mảng] = [];


Các hàm thao tác trên mảng:
push() :thêm mới dữ liệu vào cuối mảng
unshift() :thêm mới dữ liệu vào đầu mảng
pop() :xóa giá trị cuối mảng
shift() :xóa giá trị đầu mảng
splice() :thêm sửa xóa ở vị trí bất kì
join() :gộp các phần tử trong mảng thành chuỗi
*/
var car = ['audi', 'vinfast', 'ferrari'];
console.log(car[0]);
for(i=0; i<car.length; i++){
    console.log(car[i]);
}
for(var i of car){
    console.log(i);
}

car.push(18);
/*
car.splice(0,0,'ádf',500); //thêm mới vào vị trí thứ 0
car.splice(1,2); //xóa 2 phần tử ở vị trí thứ 1
car.splice(0,car.length); //xóa hết phần tử trong mảng
car.splice(0,1,'thdr'); //cập nhật vào vị trí thứ 0
*/

console.log(car.join(" "));
